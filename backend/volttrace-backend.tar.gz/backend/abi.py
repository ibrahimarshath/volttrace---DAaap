# VoltTrace contract ABI — only the functions/events we need
VOLTTRACE_ABI = [
    # --- Read functions ---
    {
        "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
        "name": "getPassport",
        "outputs": [
            {"internalType": "string",  "name": "model",       "type": "string"},
            {"internalType": "string",  "name": "serialNumber","type": "string"},
            {"internalType": "uint256", "name": "capacity",    "type": "uint256"},
            {"internalType": "string",  "name": "chemistry",   "type": "string"},
            {"internalType": "uint8",   "name": "stage",       "type": "uint8"},
            {"internalType": "bool",    "name": "stolen",      "type": "bool"},
            {"internalType": "address", "name": "assembler",   "type": "address"},
            {"internalType": "address", "name": "currentOwner","type": "address"},
        ],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
        "name": "getDocuments",
        "outputs": [
            {
                "components": [
                    {"internalType": "string",  "name": "ipfsHash",  "type": "string"},
                    {"internalType": "string",  "name": "docType",   "type": "string"},
                    {"internalType": "uint256", "name": "timestamp", "type": "uint256"},
                    {"internalType": "address", "name": "addedBy",   "type": "address"},
                ],
                "internalType": "struct VoltTrace.Document[]",
                "name": "",
                "type": "tuple[]",
            }
        ],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [],
        "name": "totalMinted",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [
            {"internalType": "bytes32", "name": "role",    "type": "bytes32"},
            {"internalType": "address", "name": "account", "type": "address"},
        ],
        "name": "hasRole",
        "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
        "name": "tokenURI",
        "outputs": [{"internalType": "string", "name": "", "type": "string"}],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
        "name": "ownerOf",
        "outputs": [{"internalType": "address", "name": "", "type": "address"}],
        "stateMutability": "view",
        "type": "function",
    },
    # --- Events ---
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True,  "internalType": "uint256", "name": "tokenId",      "type": "uint256"},
            {"indexed": False, "internalType": "string",  "name": "model",         "type": "string"},
            {"indexed": False, "internalType": "string",  "name": "serialNumber",  "type": "string"},
            {"indexed": True,  "internalType": "address", "name": "assembler",     "type": "address"},
        ],
        "name": "PassportCreated",
        "type": "event",
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True,  "internalType": "uint256", "name": "tokenId", "type": "uint256"},
            {"indexed": False, "internalType": "uint8",   "name": "from",    "type": "uint8"},
            {"indexed": False, "internalType": "uint8",   "name": "to",      "type": "uint8"},
        ],
        "name": "StageChanged",
        "type": "event",
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True,  "internalType": "uint256", "name": "tokenId",  "type": "uint256"},
            {"indexed": False, "internalType": "bool",    "name": "stolen",   "type": "bool"},
        ],
        "name": "StolenFlagChanged",
        "type": "event",
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True,  "internalType": "uint256", "name": "tokenId", "type": "uint256"},
            {"indexed": False, "internalType": "string",  "name": "ipfsHash","type": "string"},
            {"indexed": False, "internalType": "string",  "name": "docType", "type": "string"},
        ],
        "name": "DocumentAdded",
        "type": "event",
    },
]
