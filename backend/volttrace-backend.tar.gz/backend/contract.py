"""Thin wrapper around the VoltTrace contract for read-only calls."""

from web3 import Web3
from config import RPC_URL, CONTRACT_ADDRESS
from abi import VOLTTRACE_ABI

w3 = Web3(Web3.HTTPProvider(RPC_URL))
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=VOLTTRACE_ABI)

STAGE_NAMES = ["Assembled", "WithOEM", "WithOwner", "WithRecycler", "Closed"]

ROLE_HASHES = {
    "ADMIN_ROLE":     Web3.keccak(text="ADMIN_ROLE").hex(),
    "ASSEMBLER_ROLE": Web3.keccak(text="ASSEMBLER_ROLE").hex(),
    "OEM_ROLE":       Web3.keccak(text="OEM_ROLE").hex(),
    "OWNER_ROLE":     Web3.keccak(text="OWNER_ROLE").hex(),
    "RECYCLER_ROLE":  Web3.keccak(text="RECYCLER_ROLE").hex(),
    "REGULATOR_ROLE": Web3.keccak(text="REGULATOR_ROLE").hex(),
}


def get_total_minted() -> int:
    return contract.functions.totalMinted().call()


def get_passport(token_id: int) -> dict:
    result = contract.functions.getPassport(token_id).call()
    return {
        "tokenId": token_id,
        "model": result[0],
        "serialNumber": result[1],
        "capacity": result[2],
        "chemistry": result[3],
        "stage": STAGE_NAMES[result[4]] if result[4] < len(STAGE_NAMES) else str(result[4]),
        "stageIndex": result[4],
        "stolen": result[5],
        "assembler": result[6],
        "currentOwner": result[7],
    }


def get_documents(token_id: int) -> list[dict]:
    docs = contract.functions.getDocuments(token_id).call()
    return [
        {
            "ipfsHash": d[0],
            "docType": d[1],
            "timestamp": d[2],
            "addedBy": d[3],
        }
        for d in docs
    ]


def get_roles(address: str) -> list[str]:
    """Return list of role names the address holds."""
    addr = Web3.to_checksum_address(address)
    roles = []
    for name, role_hash in ROLE_HASHES.items():
        if contract.functions.hasRole(bytes.fromhex(role_hash[2:]), addr).call():
            roles.append(name.replace("_ROLE", ""))
    return roles


def get_token_uri(token_id: int) -> str:
    return contract.functions.tokenURI(token_id).call()


def get_owner_of(token_id: int) -> str:
    return contract.functions.ownerOf(token_id).call()
